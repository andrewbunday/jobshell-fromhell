# sets the shell to find the 'shows' command

alias shows='source /opt/baseblack/shows-shell/1/shows'
alias job='source /opt/baseblack/shows-shell/1/shows'
alias jobs='source /opt/baseblack/shows-shell/1/shows'
