# sets the shell to find the 'shows' command

alias shows='/opt/baseblack/shows-shell/1/shows'
alias job='/opt/baseblack/shows-shell/1/shows'
alias jobs='/opt/baseblack/shows-shell/1/shows'
